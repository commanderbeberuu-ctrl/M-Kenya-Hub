const base = process.env.BASE_URL || "http://localhost:3000";
(async()=>{
  const h=await fetch(base+"/api/health");
  if(!h.ok) throw new Error("Health check failed");
  const c=await fetch(base+"/api/config");
  if(!c.ok) throw new Error("Config endpoint failed");
  const l=await fetch(base+"/api/listings");
  if(!l.ok) throw new Error("Listings endpoint failed");
  console.log("Smoke test passed:", base);
})().catch(e=>{console.error(e);process.exit(1)});
