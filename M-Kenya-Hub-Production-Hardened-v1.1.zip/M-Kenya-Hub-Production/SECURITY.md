# Security Baseline

Implemented in this starter:
- Helmet-style security headers without an extra dependency
- Content Security Policy
- request body limits
- basic IP rate limiting
- timing-safe admin key comparison
- server-side admin endpoint authorization
- no M-Pesa credentials in frontend
- health endpoint
- environment-variable support

Still required before broad public launch:
- PostgreSQL and migrations
- named admin identities and MFA
- centralized logs
- persistent rate limiting (e.g. Redis/edge)
- backup/restore testing
- dependency scanning
- automated security tests
- formal privacy/data-protection review
- incident response process
