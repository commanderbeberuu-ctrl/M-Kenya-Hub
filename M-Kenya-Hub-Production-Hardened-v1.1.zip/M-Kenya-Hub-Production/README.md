# M-Kenya Hub — Full-Stack Starter v1.0

## What this is
A runnable front-end + back-end starter for the M-Kenya Hub idea:
- local services marketplace
- Kenyan business directory
- opportunities
- community-oriented discovery
- provider submission and moderation
- county search
- reporting
- basic admin review
- payment-information placeholder

## Run locally
Requirements: Node.js 18+.

1. Extract the ZIP.
2. Open a terminal in the extracted folder.
3. Run:
   npm install
   npm start
4. Open:
   http://localhost:3000
5. Admin:
   http://localhost:3000/admin

The database is a simple JSON file at `backend/data/db.json`. This is deliberate for the pilot and is NOT a production database.

## Current payment number
0716837065

Email: to be added later.
Bank: to be added later.

The app records a payment intention only. It does NOT claim that a payment has been received or automatically verify M-Pesa transactions. For production, connect a secure server-side M-Pesa integration.

## Before public production
- Move from JSON storage to PostgreSQL/MySQL.
- Add secure user/provider authentication.
- Add admin authentication + MFA + roles.
- Add server-side authorization on every admin endpoint.
- Add HTTPS and secure headers.
- Add rate limiting, validation, logging and backups.
- Add real verification workflow and audit trail.
- Add proper review/rating system.
- Add automated M-Pesa integration after obtaining/configuring the required Safaricom credentials.
- Complete privacy notice, terms and moderation procedures.
- Assess ODPC registration/compliance requirements before collecting production personal data.
- Add monitoring and incident-response procedures.
- Add domain, transactional messaging and support contact.

## Important
This is a complete runnable foundation, not a claim that a production marketplace can safely operate without the above controls.


## Production-hardening additions
- security headers and CSP
- request-size limits
- basic API rate limiting
- protected admin API with `ADMIN_KEY`
- Render deployment blueprint
- Dockerfile
- health check endpoint
- production deployment/security checklists
- smoke test script

## Where to run it
### On your phone
A phone alone is not the best environment for deploying Node.js. You can use an online GitHub/Render workflow.

### On a computer
Install Node.js 20+, extract the ZIP, open a terminal in the project folder:
`npm ci`
`npm start`
Then open `http://localhost:3000`.

### Public internet
Push the folder to a private GitHub repository, then deploy the repository as a Render Web Service. Use:
Build: `npm ci`
Start: `npm start`
Health check: `/api/health`
Set `ADMIN_KEY` as a secret environment variable.

Do not publish the admin key.
