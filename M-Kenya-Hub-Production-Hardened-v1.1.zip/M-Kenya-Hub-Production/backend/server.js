const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, "..");
const ADMIN_KEY = process.env.ADMIN_KEY || "";
const MAX_BODY = "200kb";
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "db.json");

const counties = [
  "Baringo","Bomet","Bungoma","Busia","Elgeyo-Marakwet","Embu","Garissa",
  "Homa Bay","Isiolo","Kajiado","Kakamega","Kericho","Kiambu","Kilifi",
  "Kirinyaga","Kisii","Kisumu","Kitui","Kwale","Laikipia","Lamu","Machakos",
  "Makueni","Mandera","Marsabit","Meru","Migori","Mombasa","Murang'a",
  "Nairobi","Nakuru","Nandi","Narok","Nyamira","Nyandarua","Nyeri",
  "Samburu","Siaya","Taita-Taveta","Tana River","Tharaka-Nithi","Trans Nzoia",
  "Turkana","Uasin Gishu","Vihiga","Wajir","West Pokot"
];

const defaultDb = {
  listings: [
    {id:1,type:"service",name:"Migori Phone & Computer Repair",category:"Technology",county:"Migori",town:"Migori",phone:"0712345678",whatsapp:"0712345678",description:"Phone, laptop and computer repair services.",verified:true,status:"approved",createdAt:"2026-09-07"},
    {id:2,type:"business",name:"M-Kenya Design Studio",category:"Creative Services",county:"Nairobi",town:"Nairobi",phone:"0720000000",whatsapp:"0720000000",description:"Graphic design, branding and digital services.",verified:false,status:"approved",createdAt:"2026-09-07"},
    {id:3,type:"opportunity",name:"Student Attachment Board",category:"Attachment",county:"Kenya",town:"All counties",phone:"",whatsapp:"",description:"A sample opportunity listing for students and graduates.",verified:true,status:"approved",createdAt:"2026-09-07"},
    {id:4,type:"service",name:"Home Cleaning Services",category:"Home Services",county:"Kisumu",town:"Kisumu",phone:"0700000000",whatsapp:"0700000000",description:"Residential and office cleaning services.",verified:false,status:"approved",createdAt:"2026-09-07"}
  ],
  reports: [],
  payments: []
};

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, {recursive:true});
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify(defaultDb,null,2));

function loadDb() {
  return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
}
function saveDb(db) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(db,null,2));
}
function nextId(items) {
  return items.reduce((m,x)=>Math.max(m, Number(x.id)||0),0)+1;
}

app.disable("x-powered-by");
app.use((req,res,next)=>{
  res.setHeader("X-Content-Type-Options","nosniff");
  res.setHeader("X-Frame-Options","DENY");
  res.setHeader("Referrer-Policy","strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy","camera=(), microphone=(), geolocation=()");
  res.setHeader("Content-Security-Policy","default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  next();
});
app.use(express.json({limit:MAX_BODY}));
app.use(express.urlencoded({extended:false, limit:MAX_BODY}));

const rateMap = new Map();
function rateLimit(windowMs=60000,max=60){
  return (req,res,next)=>{
    const key = req.ip || "unknown";
    const now=Date.now();
    let r=rateMap.get(key);
    if(!r || now-r.start>windowMs){r={start:now,count:0};rateMap.set(key,r);}
    r.count++;
    if(r.count>max) return res.status(429).json({error:"Too many requests. Please try again later."});
    next();
  };
}
function requireAdmin(req,res,next){
  if(!ADMIN_KEY) return res.status(503).json({error:"Admin access is not configured. Set ADMIN_KEY on the server."});
  const supplied=String(req.get("x-admin-key")||"");
  if(!supplied || supplied.length!==ADMIN_KEY.length || !crypto.timingSafeEqual(Buffer.from(supplied),Buffer.from(ADMIN_KEY))){
    return res.status(401).json({error:"Unauthorized"});
  }
  next();
}
app.use("/api/", rateLimit());
app.use(express.static(path.join(ROOT,"frontend"), {extensions:["html"]}));

app.get("/api/health", (req,res)=>res.status(200).json({ok:true,service:"M-Kenya Hub",version:"1.1.0"}));

app.get("/api/config", (req,res)=>res.json({
  name:"M-Kenya Hub",
  tagline:"Find. Connect. Grow.",
  paymentNumber:"0716837065",
  email:"To be added later",
  bank:"To be added later",
  counties
}));

app.get("/api/listings", (req,res)=>{
  const db=loadDb();
  const q=(req.query.q||"").toLowerCase().trim();
  const county=(req.query.county||"").toLowerCase().trim();
  const type=(req.query.type||"").toLowerCase().trim();
  const results=db.listings.filter(x=>{
    if(x.status!=="approved") return false;
    if(county && x.county.toLowerCase()!==county && x.county.toLowerCase()!=="kenya") return false;
    if(type && x.type.toLowerCase()!==type) return false;
    if(!q) return true;
    return [x.name,x.category,x.county,x.town,x.description].join(" ").toLowerCase().includes(q);
  });
  res.json(results);
});

app.post("/api/listings", (req,res)=>{
  const body=req.body||{};
  const required=["type","name","category","county","town","phone","description"];
  for(const k of required) if(!String(body[k]||"").trim()) return res.status(400).json({error:`Missing field: ${k}`});
  if(!counties.includes(body.county) && body.county!=="Kenya") return res.status(400).json({error:"Select a valid county."});
  const db=loadDb();
  const listing={
    id:nextId(db.listings),
    type:String(body.type),
    name:String(body.name).trim(),
    category:String(body.category).trim(),
    county:String(body.county).trim(),
    town:String(body.town).trim(),
    phone:String(body.phone).trim(),
    whatsapp:String(body.whatsapp||"").trim(),
    description:String(body.description).trim(),
    verified:false,
    status:"pending",
    createdAt:new Date().toISOString()
  };
  db.listings.push(listing); saveDb(db);
  res.status(201).json({message:"Submitted for review.",listing});
});

app.post("/api/reports",(req,res)=>{
  const body=req.body||{};
  if(!body.listingId || !body.reason) return res.status(400).json({error:"Listing and reason are required."});
  const db=loadDb();
  const report={id:nextId(db.reports),listingId:Number(body.listingId),reason:String(body.reason),details:String(body.details||"").trim(),createdAt:new Date().toISOString(),status:"open"};
  db.reports.push(report); saveDb(db); res.status(201).json({message:"Report received.",report});
});

app.post("/api/payments/intention",(req,res)=>{
  const body=req.body||{};
  const amount=Number(body.amount);
  if(!amount || amount<1) return res.status(400).json({error:"Enter a valid amount."});
  const db=loadDb();
  const payment={id:nextId(db.payments),amount,phone:"0716837065",reference:String(body.reference||"").trim(),purpose:String(body.purpose||"").trim(),status:"manual_pending",createdAt:new Date().toISOString()};
  db.payments.push(payment); saveDb(db);
  res.status(201).json({message:"Payment intention recorded. Automatic M-Pesa confirmation is not enabled in this starter build.",payment});
});

app.get("/api/admin/listings",requireAdmin,(req,res)=>res.json(loadDb().listings));
app.get("/api/admin/reports",requireAdmin,(req,res)=>res.json(loadDb().reports));
app.post("/api/admin/listings/:id/approve",requireAdmin,(req,res)=>{
  const db=loadDb(); const x=db.listings.find(a=>a.id===Number(req.params.id));
  if(!x) return res.status(404).json({error:"Listing not found."});
  x.status="approved"; saveDb(db); res.json(x);
});
app.post("/api/admin/listings/:id/verify",requireAdmin,(req,res)=>{
  const db=loadDb(); const x=db.listings.find(a=>a.id===Number(req.params.id));
  if(!x) return res.status(404).json({error:"Listing not found."});
  x.status="approved"; x.verified=true; saveDb(db); res.json(x);
});
app.delete("/api/admin/listings/:id",requireAdmin,(req,res)=>{
  const db=loadDb(); const before=db.listings.length;
  db.listings=db.listings.filter(a=>a.id!==Number(req.params.id));
  if(db.listings.length===before) return res.status(404).json({error:"Listing not found."});
  saveDb(db); res.json({ok:true});
});

app.get("/admin", (req,res)=>res.sendFile(path.join(ROOT,"frontend","admin.html")));
app.get("*",(req,res)=>res.sendFile(path.join(ROOT,"frontend","index.html")));

app.listen(PORT,()=>console.log(`M-Kenya Hub running at http://localhost:${PORT}`));
