# M-Kenya Hub — Production Deployment Checklist

## Recommended first deployment: Render + GitHub

Render supports Node/Express web services, HTTPS/TLS, custom domains, health checks, environment variables and automatic deploys from Git repositories.

### 1. Put the project on GitHub
Create a private repository named `m-kenya-hub`.
Upload all files from this folder.
Do NOT upload `.env` or real secrets.

### 2. Create the Render service
In Render:
- New -> Web Service
- Connect the GitHub repository
- Runtime: Node
- Build command: `npm ci`
- Start command: `npm start`
- Health check: `/api/health`

### 3. Add environment variables
Set:
- `NODE_ENV=production`
- `ADMIN_KEY=<long random secret>`

Generate a strong admin key locally with:
`node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`

Never put the real key in GitHub or in frontend JavaScript.

### 4. Database
The current JSON database is suitable only for the initial controlled pilot.
Before accepting significant real traffic, migrate listings, users, reports, reviews and payments to managed PostgreSQL.

### 5. Payment
The public number is:
`0716837065`

Automatic payment confirmation is intentionally NOT enabled in this build.
For production, use Safaricom Daraja credentials and server-side callbacks. Never put consumer secrets/passkeys in frontend code.

### 6. Domain
After the service is live, attach a domain such as:
`mkenyahub.co.ke`
(or another available domain you legally register)
Then require HTTPS.

### 7. Go-live security gate
Before opening to the public:
- named admin accounts + MFA
- PostgreSQL
- automated backups
- rate limiting at the edge
- audit logs
- provider identity/verification workflow
- privacy notice + terms
- report/appeal workflow
- monitoring and error alerts
- payment reconciliation
- secure secret storage
- data retention/deletion procedures

## Important
This repository is a production-hardened starter, not a claim that all legal, payment, identity or operational controls are complete.
